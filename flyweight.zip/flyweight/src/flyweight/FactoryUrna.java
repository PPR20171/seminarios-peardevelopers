/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flyweight;

import aleatorio.GeradorUrnaALeatoria;

/**
 * Classe responsável pelo gerenciamento da instância do objeto urna
 * @author Usuário
 */
public class FactoryUrna{

    private Urna urna;
    private GeradorUrnaALeatoria aleatorio;
    
    public Urna criar() {
        if (urna == null){
            urna = new Urna();
        }
        urna.setValor(aleatorio.getValorUrna());
        return urna;
    }
    
}